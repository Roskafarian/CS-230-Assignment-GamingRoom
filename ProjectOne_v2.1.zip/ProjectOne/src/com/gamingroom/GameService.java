package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author Ell Roska, elliott.roska@snhu.edu
 * 
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();
	private static List<Team> teams = new ArrayList<Team>();
	private static List<Player> players = new ArrayList<Player>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	private static long nextTeamId = 1;
	private static long nextPlayerId = 1;
	
	private static GameService instance = null;

	private GameService() {
	}

	public static GameService getInstance() {
    	if (instance == null) {
        	instance = new GameService();
    	}
		return instance;
	}


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		Iterator<Game> iterator = games.iterator();

		while (iterator.hasNext()) {
    		Game currentGame = iterator.next();

    		if (currentGame.getName().equals(name)) {
        		game = currentGame;
        		break;
    		}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	public Team addTeam(String name) {

    	Team team = null;

    	Iterator<Team> iterator = teams.iterator();

	    while (iterator.hasNext()) {
    	    Team currentTeam = iterator.next();

        	if (currentTeam.getName().equals(name)) {
            	team = currentTeam;
            	break;
        	}
    	}

    	if (team == null) {
        	team = new Team(nextTeamId++, name);
        	teams.add(team);
    	}

    	return team;
	}

	public Player addPlayer(String name) {

    	Player player = null;

	    Iterator<Player> iterator = players.iterator();

    	while (iterator.hasNext()) {
        	Player currentPlayer = iterator.next();

	        if (currentPlayer.getName().equals(name)) {
    	        player = currentPlayer;
        	    break;
        	}
    	}

	    if (player == null) {
    	    player = new Player(nextPlayerId++, name);
        	players.add(player);
    	}

	    return player;
	}
	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		Iterator<Game> iterator = games.iterator();

    	while (iterator.hasNext()) {
        	Game currentGame = iterator.next();

        	if (currentGame.getId() == id) {
            	game = currentGame;
            	break;
        	}
    	}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		Iterator<Game> iterator = games.iterator();

    	while (iterator.hasNext()) {
        	Game currentGame = iterator.next();

        	if (currentGame.getName().equals(name)) {
            	game = currentGame;
            	break;
        	}
    	}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
/** Brief Description:
 * The Singleton pattern is used in the GameService class to ensure that only one instance of GameService exists in memory. 
 * A private constructor prevents other classes from directly creating GameService objects, 
 * while the getInstance() method provides access to the single shared instance. 
 * The GameService instance manages the collection of active games, 
 * allowing different parts of the application to access the same game service rather than creating multiple service objects.
 * 
 * The GameService uses an iterator to search the list of active games before creating a new game. 
 * When a game with the requested name already exists, the existing Game object is returned instead of creating a duplicate. 
 * If no matching game is found, a new Game object is created, assigned a unique ID, and added to the list.
 */