package com.gamingroom;
/**
 * @author elliott.roska@snhu.edu
*/
public class Entity {
    protected long id;
    protected String name;
    
    /**
     * Protect the default constructor to prevent creating empty instances.
     */
    protected Entity() {    
    }
    /*
     * Constructor with an identifier and name
     */
    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}
